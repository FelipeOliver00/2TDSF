package br.com.fiap.jpa.view;

public class ConsoleViewAtor {

	public static void main(String[] args) {
		//Instanciar a fabrica
		
		//Instanciar o entity manager
		
		//Instanciar o AtorDAOImpl
		
		//Cadastrar um ator
		
		//Pesquisar um ator
		
		//Atualizar um ator
		
		//Remover um ator
		
		//Fechar as paradas		
		
	}
	
}
