package br.com.fiap.jpa.entity;

public enum Categoria {

	ACAO, TERROR, AVENTURA, ROMANCE, COMEDIA, SUSPENSE
	
}
