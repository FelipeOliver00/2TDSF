package br.com.fiap.jpa.entity;

public enum AreaAtuacao {

	ACAO, AVENTURA, COMEDIA, DRAMA
	
}
