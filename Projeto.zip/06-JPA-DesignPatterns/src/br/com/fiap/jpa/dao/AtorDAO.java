package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Ator;

public interface AtorDAO extends GenericDAO<Ator, Integer>{

	
}
