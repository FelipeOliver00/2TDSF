package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Filme;

public interface FilmeDAO extends GenericDAO<Filme, Integer>{

	
	
}