package br.com.fiap.jpa.exception;

public class KeyNotFoundException extends Exception {

}
