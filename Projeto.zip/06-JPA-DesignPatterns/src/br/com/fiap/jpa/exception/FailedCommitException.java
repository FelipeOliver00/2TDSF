package br.com.fiap.jpa.exception;

public class FailedCommitException extends Exception {

}
